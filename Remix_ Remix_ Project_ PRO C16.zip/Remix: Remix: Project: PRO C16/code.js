var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"monkey","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":10,"looping":true,"frameDelay":12,"version":"GMe3pdFH02yKcM_pLoHh8ayz2IxO13Vx","loadedFromSource":true,"saved":true,"sourceSize":{"x":1680,"y":1842},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"Banana","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png","frameSize":{"x":1080,"y":1080},"frameCount":1,"looping":true,"frameDelay":4,"version":".ryw74J61gLIiQpiQMAQB97jSLUufayG","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":1080},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"Stone","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"bYOwmcPmlfdxl6.HQmFwkpg66mDab.r7","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var gorilla = createSprite(40,345,10,10);
      gorilla.setAnimation("monkey");
      gorilla.scale=0.2;
      gorilla.setCollider("rectangle",0,0,gorilla.width,gorilla.height);
      
      var ground =createSprite(200,395,800,10);
      var score=0;
      
      
     
      
      var PLAY=1;
      var END=0;
      
      var invisibleground = createSprite(200,398,800,5);
      invisibleground.visible=false;
      
      var Gamestate=PLAY;
      
      var obstacle = createGroup();
      
      
      
 
 
        
      
      function draw() {
        background("white");
        drawSprites();
        createEdgeSprites(edges);
        gorilla.collide(invisibleground);
        
       textSize(26);
       text("score:"+score, 250, 55);
       
       
        
        if (Gamestate===PLAY) {
          //ground move
        ground.velocityX=-5;
        
        if (keyWentDown("space")&&gorilla.y>=366) {
          gorilla.velocityY=1-3.5;
    
        }                    
        
        if (keyWentUp("space")) {
          gorilla.velocityY=10;
         
        }
        
        gorilla.velocityY=gorilla.velocityY+0.4        ;
        
        if (ground.x<0) {
          ground.x=ground.width/2;
        }
        
   
      
        cactus();
        
        
       if (obstacle.isTouching(gorilla)) {
         gorilla.velocityY=-12;
         playSound("jump.mp3");
        }
         
        score=score+Math.round(World.frameRate/30);
        
       if (score%100===0) {
         playSound("checkPoint.mp3");
       }
       
        
        } else if (Gamestate===END) {
          //ground stop
        ground.velocityX=0;
        
          obstacle.setVelocityXEach(0);
          
          gorilla.velocityY+=0.5;
          
         cloudspawn.setVelocityXEach(0);
               
               
              gorilla.setAnimation("trexend") ;                                             
          
          gorilla.collide(invisibleground);
        
          cloudspawn.setLifetimeEach(-1);
          obstacle.setLifetimeEach(-1);
          
           GameOver.visible=true;
         Restart.visible=true;
         
        
          if (mousePressedOver(Restart)) {
            Reset();
            
         
         
          }
          
          
          
        }
        
      }
      
  
  
      
    function cactus () {
      if (World.frameCount%135===0){
        var cactus = createSprite(400,368,20,20);
        cactus.velocityX=-5;
        cactus.setAnimation("Stone");
        cactus.scale=0.2;
      obstacle.add(cactus);
        
        cactus.lifetime=85;
        
      }
    }
  





  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
